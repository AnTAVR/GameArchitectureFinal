#include <string>
#include <sstream>
#include <assert.h>

#include "Card.h"

using namespace std;

Card::Card( int value, Suit suit )
	:mValue( value )
	,mSuit( suit )
{
	assert( value >= 1 && value <= 13 );
	assert( suit >= SPADES && suit <= HEARTS );
}

string Card::getName() const
{
	stringstream theStream;

	theStream << mValue << SUIT_NAMES[mSuit];
	return theStream.str();
}