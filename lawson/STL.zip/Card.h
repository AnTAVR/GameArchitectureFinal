#pragma once

#include <string>

using namespace std;

enum Suit
{
	SPADES = 0,
	CLUBS = 1,
	DIAMONDS = 2,
	HEARTS = 3,
	NUM_SUITS
};

const string SUIT_NAMES[NUM_SUITS] = { "S", "C", "D", "H" };

class Card
{
public:
	Card( int value, Suit suit );

	inline int getValue() const { return mValue; };
	inline Suit getSuit() const { return mSuit; };

	string getName() const;

private:
	const int mValue;
	const Suit mSuit;
};